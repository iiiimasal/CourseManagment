package com.example.CourseManagment.repository;

import com.example.CourseManagment.entity.Professers;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfessorsRepository extends JpaRepository<Professers, Long> {
}
