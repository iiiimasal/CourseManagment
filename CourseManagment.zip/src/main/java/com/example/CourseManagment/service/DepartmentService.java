package com.example.CourseManagment.service;

public class DepartmentService {
}
