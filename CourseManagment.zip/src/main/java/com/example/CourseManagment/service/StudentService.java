package com.example.CourseManagment.service;

import com.example.CourseManagment.entity.Department;
import com.example.CourseManagment.entity.Lessons;
import com.example.CourseManagment.entity.Student;
//import com.example.CourseManagment.repository.StudentRepository;
//import org.springframework.beans.factory.annotation.Autowired;
import com.example.CourseManagment.repository.StudentRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.sql.SQLOutput;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class StudentService {
    StudentRepository studentRepository;
@Autowired
    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }



public List<Student> getStudents() {
   return studentRepository.findAll();

}

    public void addNewStudent(Student student ) {
       studentRepository.save(student);

    }

    public void DeletStudent(Long id) {
        boolean exists= studentRepository.existsById(id);
        if(!exists){
            throw new IllegalStateException("Student with id "+id+"does not exists");

        }
        studentRepository.deleteById(id);
    }

    public void updatestudent(Long id, String lesson, String department) {
//        Student student=studentRepository.findById(id).orElseThrow(()-> new IllegalStateException(
//                "student with id "+id+"does not exist"
//        ));
//        if(lesson!=null &&
//                lesson.length()>0 && department!=null&&department.length()>0
//               ){ //if the name provided is not the same as the current one update
//            student.setDepartment(department);
//       //     student.set
        }
}


