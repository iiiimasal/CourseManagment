package com.example.CourseManagment.entity;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table
public class Professers {
    @Id

    private long professer_id;
    private String firstname_professor;
    private String lastname_professor;
    private  long NationalNum_professor;
    @OneToMany(mappedBy = "professor")

    private List<Lessons> professor_lessons;

    // One-to-one relationship with Department
    @OneToOne(mappedBy = "manager")
    private Department department;

    @ManyToOne()
    @JoinColumn(name = "professor-list")
    private Department Department;
    public Professers(long professer_id,
                      String firstname_professor,
                      String lastname_professor,
                      long nationalNum_professor,
                      List<Lessons> professor_lessons) {
        this.professer_id = professer_id;
        this.firstname_professor = firstname_professor;
        this.lastname_professor = lastname_professor;
        NationalNum_professor = nationalNum_professor;
        this.professor_lessons = professor_lessons;
    }

    public Professers() {
    }

    public long getProfesser_id() {
        return professer_id;
    }

    public void setProfesser_id(long professer_id) {
        this.professer_id = professer_id;
    }

    public String getFirstname_professor() {
        return firstname_professor;
    }

    public void setFirstname_professor(String firstname_professor) {
        this.firstname_professor = firstname_professor;
    }

    public String getLastname_professor() {
        return lastname_professor;
    }

    public void setLastname_professor(String lastname_professor) {
        this.lastname_professor = lastname_professor;
    }

    public long getNationalNum_professor() {
        return NationalNum_professor;
    }

    public void setNationalNum_professor(long nationalNum_professor) {
        NationalNum_professor = nationalNum_professor;
    }

    public List<Lessons> getProfessor_lessons() {
        return professor_lessons;
    }

    public void setProfessor_lessons(List<Lessons> professor_lessons) {
        this.professor_lessons = professor_lessons;
    }
}
