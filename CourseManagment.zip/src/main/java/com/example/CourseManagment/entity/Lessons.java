package com.example.CourseManagment.entity;

import jakarta.persistence.*;

import java.util.List;
@Entity
@Table

public class Lessons {
    @Id
    @Column(nullable = false,
            unique = true,
            length = 64)
    private  String lesson_name;
    @Column(nullable = false)
    private Integer Credit;


    // Many-to-one relationship with Student
    @ManyToOne
    @JoinColumn(name = "id") // The name of the foreign key column in the Lessons table
    private Student student;

    @Column(nullable = true)
    // One-to-many relationship with Student (reverse relationship)
    @OneToMany(mappedBy = "lessons", cascade = CascadeType.ALL)
    private List<Student> studentList;
    @ManyToOne
    @JoinColumn(name = "lesson_list")
    private Department department;

    @ManyToOne
   @JoinColumn(name = "professer_id")
    private Professers professor;
    public Lessons(String lesson_name,
                   Integer credit,
                   List<Student> studentList) {
        this.lesson_name = lesson_name;
        Credit = credit;
        this.studentList = studentList;
    }

    public Lessons() {

    }

    public Lessons(String lesson_name, Integer credit ,Professers professor) {
        this.lesson_name = lesson_name;
        Credit = credit;
        this.professor=professor;
    }

    public String getLesson_name() {
        return lesson_name;
    }

    public void setLesson_name(String lesson_name) {
        this.lesson_name = lesson_name;
    }

    public Integer getCredit() {
        return Credit;
    }

    public void setCredit(Integer credit) {
        Credit = credit;
    }

    public List<Student> getStudentList() {
        return studentList;
    }

    public void setStudentList(List<Student> studentList) {
        this.studentList = studentList;
    }
}
